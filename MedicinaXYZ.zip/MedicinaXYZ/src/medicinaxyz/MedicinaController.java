/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medicinaxyz;

import java.util.ArrayList;

/**
 *
 * @author jhose
 */
public class MedicinaController {
    ArrayList<Medicina> lista = new ArrayList();
    
    public void AgregarPersona (Medicina nuevapersona){
        lista.add(nuevapersona);
    }
    public void listarPersonas(){
        System.out.println("La lista contiene las siguientes pacientes es: ");
        for(int i=0; i<lista.size();i++){
            Medicina m1 = lista.get(i);
            m1.VerDatos();
        }
    }
}
