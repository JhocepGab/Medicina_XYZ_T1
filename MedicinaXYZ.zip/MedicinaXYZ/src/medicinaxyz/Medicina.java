/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medicinaxyz;

import java.time.LocalDate;

/**
 *
 * @author jhose
 */
public class Medicina {
    private String tipo_doc;
    private String nro_documento;
    private String nombre;
    private String ape_paterno;
    private String ape_materno;
    private String tipo_sangre;
    private String alergia;
    private String correo;
    private String telefono;
    private String edad;

    public String getTipo_doc() {
        return tipo_doc;
    }

    public void setTipo_doc(String tipo_doc) {
        if(tipo_doc.equals("DNI") || tipo_doc.equals("CE")){
            this.tipo_doc = tipo_doc;
        }
        else{
            System.out.println("Invalido");
        }
    }

    public String getNro_documento() {
        return nro_documento;
    }

    public void setNro_documento(String nro_documento) {
        if (this.tipo_doc == null){
            System.out.println("Primero debe de ingresar el tipo de documento");
            return;
        }
        if (this.tipo_doc.equals("DNI") || nro_documento.length() == 8) {
        this.nro_documento = nro_documento;
    } 
    else if (this.tipo_doc.equals("CE") || nro_documento.length() == 10) {
        this.nro_documento = nro_documento;
    } 
    else {
        System.out.println("Error: Para " + this.tipo_doc + " el número debe tener " + 
                           (this.tipo_doc.equals("DNI") ? "8" : "10") + " dígitos.");
         }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApe_paterno() {
        return ape_paterno;
    }

    public void setApe_paterno(String ape_paterno) {
        this.ape_paterno = ape_paterno;
    }

    public String getApe_materno() {
        return ape_materno;
    }

    public void setApe_materno(String ape_materno) {
        this.ape_materno = ape_materno;
    }

    public String getTipo_sangre() {
        return tipo_sangre;
    }

    public void setTipo_sangre(String tipo_sangre) {
        this.tipo_sangre = tipo_sangre;
    }

    public String getAlergia() {
        return alergia;
    }

    public void setAlergia(String alergia) {
        this.alergia = alergia;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        if(correo.equals("con")){
            this.correo = correo;
        }
        else{
            System.out.println("Invalido");
        }
        
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        if (telefono.length() == 9) {
        this.telefono = telefono;
    }
    else {
        System.out.println("El telefono del paciente debe de tener 9 digitos");
         }
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
        
    }
    public LocalDate getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(LocalDate fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }
    LocalDate fecha_nacimiento; 
    
    
    
    public void VerDatos(){
        System.out.println(" Persona TIPO DOC: " +this.tipo_doc +
                "nro documento : " + this.nro_documento+" NOMBRE: "+this.nombre+
                " apellido : "+ this.ape_paterno + " apellido materno: " + this.ape_materno+
                " Tipo de SAngre: "+this.tipo_sangre + " Alergias: " + this.alergia + 
                " Correo Electronico " + this.correo + " Número telefonico: " + this.telefono +
                " Edad: " + this.edad);
    }
}
