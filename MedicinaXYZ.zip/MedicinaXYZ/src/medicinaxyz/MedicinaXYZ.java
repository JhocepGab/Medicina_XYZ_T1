/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package medicinaxyz;

import java.util.Scanner;

/**
 *
 * @author jhose
 */
public class MedicinaXYZ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Medicina m1 = new Medicina();
        String rpta="s";
        MedicinaController controla = new MedicinaController();
        while(rpta.equalsIgnoreCase("s")){
        
        System.out.println("Ingrese tipo de documento (DNI o CE)");
        String tipo = sc.nextLine();
        m1.setTipo_doc(tipo);
        
        System.out.println("Ingrese nuemero de documento");
        String nro = sc.nextLine();
        m1.setNro_documento(nro);
        
        System.out.println("Ingrese su nombre: ");
        String nom = sc.nextLine();
        m1.setNombre(nom);
        
        System.out.println("Ingrese su apellido paterno");
        String ape_pe = sc.nextLine();
        m1.setApe_paterno(ape_pe);
        
        System.out.println("Ingrese su apellido materno");
        String ape_ma = sc.nextLine();
        m1.setApe_paterno(ape_ma);
        
        System.out.println("Ingrese su tipo de sangre");
        String sangre = sc.nextLine();
        m1.setTipo_sangre(sangre);
        
        System.out.println("Ingrese si tiene una alergia");
        String ale = sc.nextLine();
        m1.setAlergia(ale);
        
        System.out.println("Ingrese su correo electrinico");
        String corre = sc.nextLine();
        m1.setCorreo(corre);
        
        System.out.println("Ingrese su número de telefono");
        String tele = sc.nextLine();
        m1.setTelefono(tele);
        
        System.out.println("Ingrese su edad del paciente");
        String ed = sc.nextLine();
        m1.setEdad(ed);
        
        
                controla.AgregarPersona(m1);
                    System.out.println("Desea ingresar otra persona s/n");
                    rpta=sc.nextLine();
        }
                controla.listarPersonas();
    }
    
}
